import fs from 'fs';
import path from 'path';
import https from 'https';

const TOKEN = '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';
const OWNER = 'AADI-playz23';
const REPO = 'Absora-AI-Hub';
const ROOT_DIR = path.resolve('.');

function ghReq(apiPath, method = 'GET', body = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'api.github.com',
      path: apiPath.startsWith('/repos/') || apiPath.startsWith('/user') ? apiPath : `/repos/${OWNER}/${REPO}${apiPath}`,
      method,
      headers: {
        'Authorization': `token ${TOKEN}`,
        'User-Agent': 'Absora-App',
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json'
      }
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch (e) {
          resolve({ status: res.statusCode, raw: data });
        }
      });
    });

    req.on('error', reject);
    if (body) req.write(JSON.stringify(body));
    req.end();
  });
}

function getAllFiles(dirPath, arrayOfFiles = []) {
  const files = fs.readdirSync(dirPath);

  files.forEach(file => {
    if (file === 'node_modules' || file === '.git' || file === '.vscode' || file === 'dist' || file === 'push_via_api.js' || file === 'push_to_github.js') return;
    const fullPath = path.join(dirPath, file);
    if (fs.statSync(fullPath).isDirectory()) {
      arrayOfFiles = getAllFiles(fullPath, arrayOfFiles);
    } else {
      arrayOfFiles.push(fullPath);
    }
  });

  return arrayOfFiles;
}

async function run() {
  console.log(`[1/4] Ensuring repository is initialized with auto_init...`);
  // Try initializing by uploading README via contents API with auto_init check
  const contentsRes = await ghReq(`/repos/${OWNER}/${REPO}/contents/INIT.md`, 'PUT', {
    message: 'Initial repository commit',
    content: Buffer.from('# Absora AI Hub\nOn-Demand SLM Model Hosting Platform').toString('base64')
  });

  console.log(`Repository init status: ${contentsRes.status}`);

  console.log(`[2/4] Scanning files in ${ROOT_DIR}...`);
  const allFiles = getAllFiles(ROOT_DIR);
  console.log(`Found ${allFiles.length} files to upload.`);

  const treeItems = [];

  for (let i = 0; i < allFiles.length; i++) {
    const file = allFiles[i];
    const relPath = path.relative(ROOT_DIR, file).replace(/\\/g, '/');
    const content = fs.readFileSync(file);

    process.stdout.write(`Uploading file ${i + 1}/${allFiles.length}: ${relPath}... `);
    const isBinary = content.includes(0);
    const blobRes = await ghReq(`/repos/${OWNER}/${REPO}/git/blobs`, 'POST', {
      content: content.toString(isBinary ? 'base64' : 'utf8'),
      encoding: isBinary ? 'base64' : 'utf8'
    });

    if (blobRes.status === 201) {
      console.log('✓');
      treeItems.push({
        path: relPath,
        mode: '100644',
        type: 'blob',
        sha: blobRes.body.sha
      });
    } else {
      console.log('✗', blobRes.body);
    }
  }

  console.log('[3/4] Creating Git Tree...');
  const treeRes = await ghReq(`/repos/${OWNER}/${REPO}/git/trees`, 'POST', {
    tree: treeItems
  });

  if (treeRes.status !== 201) {
    console.error('Failed to create tree:', treeRes.body);
    return;
  }

  const treeSha = treeRes.body.sha;
  console.log(`Tree created SHA: ${treeSha}`);

  // Get current main branch ref
  const refRes = await ghReq(`/repos/${OWNER}/${REPO}/git/refs/heads/main`);
  const parentSha = refRes.body?.object?.sha;

  console.log('[4/4] Creating Commit & updating main branch...');
  const commitRes = await ghReq(`/repos/${OWNER}/${REPO}/git/commits`, 'POST', {
    message: 'Push complete Absora AI Hub platform codebase',
    tree: treeSha,
    parents: parentSha ? [parentSha] : []
  });

  if (commitRes.status !== 201) {
    console.error('Failed to create commit:', commitRes.body);
    return;
  }

  const commitSha = commitRes.body.sha;
  console.log(`Commit created SHA: ${commitSha}`);

  await ghReq(`/repos/${OWNER}/${REPO}/git/refs/heads/main`, 'PATCH', {
    sha: commitSha,
    force: true
  });

  console.log('\n' + '═'*60);
  console.log(`🎉 SUCCESS! All Absora AI Hub code successfully pushed to GitHub:`);
  console.log(`   https://github.com/${OWNER}/${REPO}`);
  console.log('═'*60 + '\n');
}

run().catch(console.error);
