import { execSync } from 'child_process';
import https from 'https';

const TOKEN = process.env.GH_TOKEN || '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';

function ghApi(path, method = 'GET', data = null) {
  return new Promise((resolve, reject) => {
    const options = {
      hostname: 'api.github.com',
      path,
      method,
      headers: {
        'Authorization': `token ${TOKEN}`,
        'User-Agent': 'Absora-App',
        'Accept': 'application/vnd.github.v3+json',
        'Content-Type': 'application/json'
      }
    };

    const req = https.request(options, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, data: JSON.parse(body) });
        } catch (e) {
          resolve({ status: res.statusCode, raw: body });
        }
      });
    });

    req.on('error', reject);
    if (data) req.write(JSON.stringify(data));
    req.end();
  });
}

async function main() {
  console.log('[1/4] Authenticating with GitHub API...');
  const userRes = await ghApi('/user');
  if (userRes.status !== 200) {
    console.error('Failed to authenticate:', userRes);
    process.exit(1);
  }
  const username = userRes.data.login;
  console.log(`Authenticated as GitHub user: ${username}`);

  console.log('[2/4] Creating repository "Absora-AI-Hub"...');
  const repoRes = await ghApi('/user/repos', 'POST', {
    name: 'Absora-AI-Hub',
    private: false,
    description: 'Absora AI Hub — On-Demand SLM Model Hosting & Endpoint Platform'
  });

  if (repoRes.status === 201) {
    console.log(`Repository created successfully: ${repoRes.data.html_url}`);
  } else if (repoRes.status === 422) {
    console.log(`Repository "Absora-AI-Hub" already exists under account ${username}. Proceeding to push.`);
  } else {
    console.log(`Repository creation response (${repoRes.status}):`, repoRes);
  }

  console.log('[3/4] Initializing Git repository and committing files...');
  try {
    execSync('git init', { stdio: 'inherit' });
    execSync(`git config user.name "${username}"`, { stdio: 'inherit' });
    execSync(`git config user.email "${username}@users.noreply.github.com"`, { stdio: 'inherit' });
    execSync('git add .', { stdio: 'inherit' });
    execSync('git commit -m "Initial commit of Absora AI Hub full-stack platform"', { stdio: 'inherit' });
    execSync('git branch -M main', { stdio: 'inherit' });
  } catch (e) {
    console.log('Git commit note:', e.message);
  }

  console.log('[4/4] Pushing code to GitHub remote...');
  const remoteUrl = `https://${TOKEN}@github.com/${username}/Absora-AI-Hub.git`;
  try {
    try { execSync('git remote remove origin', { stdio: 'ignore' }); } catch {}
    execSync(`git remote add origin ${remoteUrl}`, { stdio: 'inherit' });
    execSync('git push -u origin main --force', { stdio: 'inherit' });
    console.log(`\n🎉 SUCCESS! All code successfully pushed to: https://github.com/${username}/Absora-AI-Hub`);
  } catch (e) {
    console.error('Failed to push to GitHub:', e.message);
  }
}

main();
